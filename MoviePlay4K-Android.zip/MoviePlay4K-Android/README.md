# MoviePlay4K (Android)

Material 3 video player. Media3 ExoPlayer + FFmpeg software decoders (NextLib), so formats the phone's
hardware decoder cannot handle fall back to FFmpeg. No re-encoding, original quality.

Features: playlist, add videos / add whole folder (with sidecar .srt/.vtt/.ass), remove items, brightness and
volume sliders, +-10s, double-tap seek, speed 0.25x-4x, audio/subtitle track switching, screen fit,
fullscreen + auto landscape, Picture-in-Picture, HDR10/HLG label, opens videos from file managers.
No login, no like/comment/share, no browse. Follows the device dark/light theme.

## Get the APK
**GitHub (no setup):** create a repo, upload this folder, open Actions -> "Build APK" -> Run workflow.
Download `MoviePlay4K-apk` from the run (it contains `app-release.apk`).

**Android Studio:** File -> Open this folder, wait for sync, Build -> Build APK(s).

Note: the APK is signed with the debug key so it installs directly. Use your own key for the Play Store.
